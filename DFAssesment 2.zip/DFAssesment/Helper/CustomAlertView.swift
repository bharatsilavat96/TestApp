//
//  CustomAlertView.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import Foundation
import UIKit

import UIKit

class CustomAlertView: UIView {
    
    private let headerView: UIView = {
        let view = UIView()
        view.backgroundColor = .lightGray
        return view
    }()
    
    private let headerLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.font = UIFont.boldSystemFont(ofSize: 18)
        return label
    }()
    
    private let closeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "cross"), for: .normal) // Replace "cross" with the actual image name
        button.addTarget(self, action: #selector(closeButtonTapped), for: .touchUpInside)
        return button
    }()
    
    private let bodyView: UIView = {
        let view = UIView()
        view.backgroundColor = .white
        return view
    }()
    
    private let deskIdLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    private let deskNoLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    private let slotLabel: UILabel = {
        let label = UILabel()
        label.textColor = .black
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    
    var onCloseButtonTapped: (() -> Void)?
    
    init() {
        super.init(frame: .zero)
        setupUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupUI()
    }
    
    private func setupUI() {
        // Add subviews
        addSubview(headerView)
        headerView.addSubview(headerLabel)
        headerView.addSubview(closeButton)
        
        addSubview(bodyView)
        bodyView.addSubview(deskIdLabel)
        bodyView.addSubview(deskNoLabel)
        bodyView.addSubview(slotLabel)
        
        headerView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            headerView.topAnchor.constraint(equalTo: topAnchor),
            headerView.leadingAnchor.constraint(equalTo: leadingAnchor),
            headerView.trailingAnchor.constraint(equalTo: trailingAnchor),
            headerView.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        headerLabel.translatesAutoresizingMaskIntoConstraints = false
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            headerLabel.leadingAnchor.constraint(equalTo: headerView.leadingAnchor, constant: 16),
            headerLabel.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            
            closeButton.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -16),
            closeButton.centerYAnchor.constraint(equalTo: headerView.centerYAnchor),
            closeButton.widthAnchor.constraint(equalToConstant: 30),
            closeButton.heightAnchor.constraint(equalToConstant: 30)
        ])
        
        bodyView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            bodyView.topAnchor.constraint(equalTo: headerView.bottomAnchor),
            bodyView.leadingAnchor.constraint(equalTo: leadingAnchor),
            bodyView.trailingAnchor.constraint(equalTo: trailingAnchor),
            bodyView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        deskIdLabel.translatesAutoresizingMaskIntoConstraints = false
        deskNoLabel.translatesAutoresizingMaskIntoConstraints = false
        slotLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            deskIdLabel.topAnchor.constraint(equalTo: bodyView.topAnchor, constant: 16),
            deskIdLabel.leadingAnchor.constraint(equalTo: bodyView.leadingAnchor, constant: 16),
            deskIdLabel.trailingAnchor.constraint(equalTo: bodyView.trailingAnchor, constant: -16),
            
            deskNoLabel.topAnchor.constraint(equalTo: deskIdLabel.bottomAnchor, constant: 8),
            deskNoLabel.leadingAnchor.constraint(equalTo: bodyView.leadingAnchor, constant: 16),
            deskNoLabel.trailingAnchor.constraint(equalTo: bodyView.trailingAnchor, constant: -16),
            
            slotLabel.topAnchor.constraint(equalTo: deskNoLabel.bottomAnchor, constant: 8),
            slotLabel.leadingAnchor.constraint(equalTo: bodyView.leadingAnchor, constant: 16),
            slotLabel.trailingAnchor.constraint(equalTo: bodyView.trailingAnchor, constant: -16),
            slotLabel.bottomAnchor.constraint(equalTo: bodyView.bottomAnchor, constant: -16)
        ])
    }
    
    @objc private func closeButtonTapped() {
        onCloseButtonTapped?()
    }
}
