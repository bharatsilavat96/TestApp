//
//  AvilabilityModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct AvilabilityModel: Codable{
    let availability: [AvailabilityInfo]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.availability, forKey: .availability)
    }
    enum CodingKeys: CodingKey {
        case availability
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.availability = try container.decodeIfPresent([AvailabilityInfo].self, forKey: .availability)
    }
}

struct AvailabilityInfo: Codable {
    let workSpaceName: String?
    let workSpaceId: Int?
    let workSpaceActive: Bool?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.workSpaceName, forKey: .workSpaceName)
        try container.encodeIfPresent(self.workSpaceId, forKey: .workSpaceId)
        try container.encodeIfPresent(self.workSpaceActive, forKey: .workSpaceActive)
    }
    
    enum CodingKeys: String, CodingKey {
        case workSpaceName = "workspace_name"
        case workSpaceId = "workspace_id"
        case workSpaceActive = "workspace_active"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.workSpaceName = try container.decodeIfPresent(String.self, forKey: .workSpaceName)
        self.workSpaceId = try container.decodeIfPresent(Int.self, forKey: .workSpaceId)
        self.workSpaceActive = try container.decodeIfPresent(Bool.self, forKey: .workSpaceActive)
    }
    
    
}
