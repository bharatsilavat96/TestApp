//
//  LoginModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct LoginResponse: Decodable {
    let userId: Int
    let message: String
    
}
