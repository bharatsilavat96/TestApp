//
//  CreateAccountModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct CreateAccount {
    var fullName: String
    var mobileNumber: String
    var email: String
}
