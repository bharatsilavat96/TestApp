//
//  BookingHistoryViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class BookingHistoryViewController: UIViewController, GetBookingViewModelDelegate {
    
    @IBOutlet weak var bookingHistoryTableView: UITableView!
    
    let getBookingsModel = GetBookingViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        self.title = "Booking history"
    }
    private func setupUI(){
        getBookingsModel.delegate = self
        getBookingsModel.fetchData()
        bookingHistoryTableView.delegate = self
        bookingHistoryTableView.dataSource = self
        bookingHistoryTableView.separatorStyle = .none
        
    }
    func didFinishFetchingData(with result: Result<Void, Error>) {
        switch result{
        case .success:
            DispatchQueue.main.async {
                self.bookingHistoryTableView.reloadData()
            }
        case .failure(let error):
            print("Fetching Error : \(error)")
        }
    }
    
}
extension BookingHistoryViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = getBookingsModel.bookingData.count
        return 8
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookingHistoryTableViewCell", for: indexPath) as! BookingHistoryTableViewCell
        cell.backGroundView.roundCorners(10, borderWidth: 0, borderColor: .clear)
//        let data =  getBookingsModel.bookingData[indexPath.row]
//        print(data)
//        cell.bookedOnLabel.text = data.bookingDate
//        cell.deskIdLabel.text = "\(data.workSpaceId ?? 0)"
//        cell.nameLabel.text = data.workSpaceName
        return cell
    }
}
extension BookingHistoryViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
}

