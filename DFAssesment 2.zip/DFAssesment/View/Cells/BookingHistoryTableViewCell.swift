//
//  BookingHistoryTableViewCell.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import UIKit

class BookingHistoryTableViewCell: UITableViewCell {
    
    @IBOutlet weak var deskIdLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var bookedOnLabel: UILabel!
    @IBOutlet weak var backGroundView: UIView!
    
}
