//
//  DateCollectionViewCell.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import UIKit

class DateCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var monthLabel: UILabel!
    
}
