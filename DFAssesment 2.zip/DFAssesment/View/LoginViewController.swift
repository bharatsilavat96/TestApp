//
//  LoginViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet private weak var emailIdTextField: UITextField!
    @IBOutlet private weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    
    private var viewModel = LoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        manageUI()
    }
    
    @IBAction private func loginButtonTapped(_ sender: UIButton) {
        viewModel.username = emailIdTextField.text ?? ""
        viewModel.password = passwordTextField.text ?? ""
        viewModel.login()
        let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "BookingViewController") as! BookingViewController
        goToVC.modalPresentationStyle = .fullScreen
        present(goToVC, animated: true)
    }
    
    @IBAction func newUserButtonAction(_ sender: Any) {
        print("New User Button Tapped")
    }
    
    private func manageUI() {
        self.emailIdTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        self.passwordTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        loginButton.roundCorners(10, borderWidth: 0, borderColor: .blue)
        
    }
    
}
