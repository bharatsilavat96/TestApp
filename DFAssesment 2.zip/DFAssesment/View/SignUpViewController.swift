//
//  SignUpViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class SignUpViewController: UIViewController {
    
    @IBOutlet private weak var fullNameTextField: UITextField!
    @IBOutlet private weak var mobileNumberTextField: UITextField!
    @IBOutlet private weak var emailTextField: UITextField!
    @IBOutlet private weak var createAccountButton: UIButton!
    
    private var viewModel = CreateAccountViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    @IBAction private func createAccountButtonAction(_ sender: UIButton) {
        // Validate and save the profile
        viewModel.createAccountObject.fullName = fullNameTextField.text ?? ""
        viewModel.createAccountObject.email = emailTextField.text ?? ""
        viewModel.createAccountObject.mobileNumber = mobileNumberTextField.text ?? ""
        
        if validateProfile() {
            saveProfile()
        } else {
            showAlert(message: "Please fill in all the fields.")
        }
    }
    
    @IBAction func exitingUserLoginAction(_ sender: Any) {
        print("Exiting User Button Tapped")
    }
    
    private func validateProfile() -> Bool {
        return !viewModel.createAccountObject.fullName.isEmpty &&
        !viewModel.createAccountObject.mobileNumber.isEmpty &&
        !viewModel.createAccountObject.email.isEmpty
    }
    
    private func saveProfile() {
        print("Profile Saved:")
        print("Full Name: \(viewModel.createAccountObject.fullName)")
        print("Mobile Number: \(viewModel.createAccountObject.mobileNumber)")
        print("Email: \(viewModel.createAccountObject.email)")
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    private func setupUI(){
        fullNameTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        mobileNumberTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        emailTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        createAccountButton.roundCorners(10, borderWidth: 0, borderColor: .blue)
    }
    
}
