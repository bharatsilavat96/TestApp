//
//  AvailableDeskViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class AvailableDeskViewController: UIViewController,AvailabilityViewModelDelegate {
    
    @IBOutlet weak var availabilityDeskCollectionView: UICollectionView!
    @IBOutlet weak var bookDeskButton: UIButton!
    @IBOutlet weak var cancelAlertButton: UIButton!
    @IBOutlet weak var alertDeskIdLabel: UILabel!
    @IBOutlet weak var alertDeskNoLabel: UILabel!
    @IBOutlet weak var alertSlotTimeLabel: UILabel!
    @IBOutlet weak var alertConfirmButton: UIButton!
    @IBOutlet weak var alertView: UIView!
    
    let availabilityModel = AvailabilityViewModel()
    var currentBokingDetail : AvailabilityInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        self.title = "Available desks"
    }
    
    @IBAction func bookDeskButtonAction(sender:UIButton){
        print("Book Desk Button tapped")
        alertDeskIdLabel.text = "\(currentBokingDetail?.workSpaceId ?? 0)"
        alertDeskNoLabel.text = currentBokingDetail?.workSpaceName
        alertConfirmButton.addTarget(self, action: #selector(confirmBookingAction), for: .touchUpInside)
        cancelAlertButton.addTarget(self, action: #selector(cancelAlertButtonAction), for: .touchUpInside)
        alertView.isHidden = false
    }
    private func setupUI(){
        alertView.isHidden = true
        availabilityModel.delegate = self
        availabilityModel.fetchData()
        availabilityDeskCollectionView.delegate = self
        availabilityDeskCollectionView.dataSource = self
        bookDeskButton.roundCorners(10, borderWidth: 0, borderColor: .clear)
        bookDeskButton.backgroundColor = UIColor(hex: "#5167EB")
        alertView.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        alertConfirmButton.roundCorners(5, borderWidth: 0, borderColor: .clear)
    }
    
    func didFinishFetchingData(with result: Result<Void, Error>) {
        switch result {
        case .success:
            DispatchQueue.main.async {
                self.availabilityDeskCollectionView.reloadData()
            }
        case .failure(let error):
            print("Error fethcing data; \(error)")
        }
    }
    
    @objc func cancelAlertButtonAction(){
        print("Booking cancelled")
        self.alertView.isHidden = true
    }
    
    @objc func confirmBookingAction(){
        print("ConfirmButton clicked")
    }
    
}
extension AvailableDeskViewController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return availabilityModel.availabilityData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AvailabilityCollectionViewCell", for: indexPath) as! AvailabilityCollectionViewCell
        let workSpace = availabilityModel.availabilityData[indexPath.row].workSpaceName
        let status = availabilityModel.availabilityData[indexPath.row].workSpaceActive
        if status == false {
            cell.roundCorners(5, borderWidth: 1, borderColor: .clear)
            cell.backgroundColor = UIColor(hex: "#E3E3E3")
            cell.workSpaceNameLabel.textColor = .white
        } else {
            cell.roundCorners(5, borderWidth: 1, borderColor: UIColor(hex: "#C7CFFC"))
            cell.backgroundColor = UIColor(hex: "#F0F5FF")
        }
        cell.workSpaceNameLabel.text = workSpace
        return cell
    }
}
extension AvailableDeskViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 50, height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedWorkSpace = availabilityModel.availabilityData[indexPath.row]
        currentBokingDetail = selectedWorkSpace
        
    }
}
