//
//  LoginViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

import Foundation

class LoginViewModel {
    
    var username: String = ""
    var password: String = ""
    
    var onLoginResult: ((Result<LoginResponse, Error>) -> Void)?
    
    func login() {
        guard let url = URL(string: "https://demo0413095.mockable.io/digitalflake/api/login") else {
            print("Invalid Url ------")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let parameters: [String: Any] = [
            "username": username,
            "password": password
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters)
        } catch {
            print("There is an error in serialization ----")
            onLoginResult?(.failure(error))
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error in Managing Url Session Or Error Code ---")
                self.onLoginResult?(.failure(error))
                return
            }
            
            guard let data = data else {
                print("No Data receieved Please check Models -")
                let error = NSError(domain: "Invalid data", code: 0, userInfo: nil)
                self.onLoginResult?(.failure(error))
                return
            }
            
            do {
                let decoder = JSONDecoder()
                let loginResponse = try decoder.decode(LoginResponse.self, from: data)
                self.onLoginResult?(.success(loginResponse))
            } catch {
                print("There is an error in Decoding ----")
                self.onLoginResult?(.failure(error))
            }
        }
        
        task.resume()
    }
}
