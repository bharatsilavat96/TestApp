//
//  CreateAccountViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

class CreateAccountViewModel {
    
    var createAccountObject: CreateAccount
    
    init() {
        self.createAccountObject = CreateAccount(fullName: "", mobileNumber: "", email: "")
    }
    
    func saveProfileToServer(completion: @escaping (Result<Void, Error>) -> Void) {
        guard let url = URL(string: "https://demo0413095.mockable.io/digitalflake/api/create_account") else {
            completion(.failure(NSError(domain: "Invalid URL", code: 0, userInfo: nil)))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let parameters: [String: Any] = [
            "fullName": createAccountObject.fullName,
            "email": createAccountObject.email
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters)
        } catch {
            completion(.failure(error))
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(error))
                return
            }
            if let data = data {
                print(data.description)
            }
            
            completion(.success(()))
        }
        
        task.resume()
    }
    
}
