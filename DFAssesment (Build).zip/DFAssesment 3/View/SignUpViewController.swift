//
//  SignUpViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class SignUpViewController: UIViewController,SignUpViewModelDelegate {
    
    //MARK: - IBOulets -
    @IBOutlet private weak var fullNameTextField: UITextField!
    @IBOutlet private weak var mobileNumberTextField: UITextField!
    @IBOutlet private weak var emailTextField: UITextField!
    @IBOutlet private weak var createAccountButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    
    //MARK: - Variables -
    private var viewModel = SignUpViewModel()
    
    //MARK: - ViewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        viewModel.delegate = self
    }
    
    //MARK: - IBActions -
    @IBAction private func createAccountButtonAction(_ sender: UIButton) {
        if validateProfile() {
            viewModel.signUpUser(email: emailTextField.text ?? "", password: "password")
        } else {
            AlertManager.showAlert(title: "Alert", message: "Please fill in all the required fields with valid data.", viewController: self)
        }
    }
    
    @IBAction func exitingUserLoginAction(_ sender: Any) {
        print("Exiting User Button Tapped")
    }
    
    //MARK: - Functions -
    private func validateProfile() -> Bool {
        guard let fullName = fullNameTextField.text, !fullName.isEmpty,
              let mobileNumber = mobileNumberTextField.text, !mobileNumber.isEmpty,
              let email = emailTextField.text, !email.isEmpty else {
            return false
        }
        
        if !ValidationManager.isValidEmail(email) {
            AlertManager.showAlert(title: "Alert", message: "Email is not in valid format. Please check.", viewController: self)
            return false
        }
        return true
    }
    
    private func setupUI() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)
        
        fullNameTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        mobileNumberTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        emailTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        createAccountButton.roundCorners(10, borderWidth: 0, borderColor: .blue)
        let underlineAttribute = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedString = NSAttributedString(string: "Log In", attributes: underlineAttribute)
        loginButton.setAttributedTitle(underlineAttributedString, for: .normal)
    }
    
    //MARK: - API didFinish -
    func didFinishSignUp(with result: Result<SignUpResponse, Error>) {
        switch result {
        case .success(let signUpResponse):
            print("User ID: \(signUpResponse.userId)")
            AlertManager.showAlert(title: "Alert", message: "Your account is created succesfully", viewController: self)
        case .failure(let error):
            print("Error creating account: \(error.localizedDescription)")
            AlertManager.showAlert(title: "Alert", message: "Error creating account. Please try again.", viewController: self)
        }
    }
}

//MARK: - Keyboard Manage -
extension SignUpViewController{
    @objc func keyboardWillShow(notification:NSNotification) {
        
        guard let userInfo = notification.userInfo else { return }
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 20
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification) {
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
}
