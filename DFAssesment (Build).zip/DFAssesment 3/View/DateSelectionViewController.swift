//
//  DateSelectionViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class DateSelectionViewController: UIViewController, SlotsViewModelDelegate {
    
    //MARK: - Outlets -
    @IBOutlet weak var dateCollectionView: UICollectionView!
    @IBOutlet weak var slotTimeCollectionView: UICollectionView!
    @IBOutlet weak var nextButton: UIButton!
    
    //MARK: - Variables -
    var dateData: [Date] = []
    var slotsViewModel = SlotsViewModel()
    var isRoomOpen: Bool?
    var selectedDate: Date?
    var currentSlot: SlotsInfo?
    var selectedDateIndexPath: IndexPath?
    var selectedSlotIndexPath: IndexPath?
    
    //MARK: - ViewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        self.title = "Select Date & Slot"
    }
    
    //MARK: - IBActions -
    @IBAction func nextButtonAction(sender: UIButton){
        if let selectedDate = selectedDate, let currentSlot = currentSlot {
            if isRoomOpen != nil{
                let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "AvailabilityVC") as! AvailableDeskViewController
                goToVC.title = "Available rooms"
                goToVC.isRoomOpen = true
                goToVC.bookedslot = currentSlot
                goToVC.bookedDate = selectedDate
                goToVC.modalPresentationStyle = .fullScreen
                navigationController?.pushViewController(goToVC, animated: true)
            } else {
                let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "AvailabilityVC") as! AvailableDeskViewController
                goToVC.title = "Available desks"
                goToVC.isRoomOpen = false
                goToVC.bookedslot = currentSlot
                goToVC.bookedDate = selectedDate
                goToVC.modalPresentationStyle = .fullScreen
                navigationController?.pushViewController(goToVC, animated: true)
            }
        } else {
            print("Data is Empty Please select slot and Date")
        }
    }
    
    //MARK: - Functions -
    private func hitApi(withDate: Date){
        
        slotsViewModel.fetchData(for: withDate)
        selectedSlotIndexPath = nil
        slotTimeCollectionView.reloadData()
    }
    
    private func setupUI(){
        selectedDate = Date()
        hitApi(withDate: selectedDate!)
        slotsViewModel.delegate = self
        dateCollectionView.delegate = self
        dateCollectionView.dataSource = self
        slotTimeCollectionView.delegate = self
        slotTimeCollectionView.dataSource = self
        dateCollectionView.reloadData()
        nextButton.roundCorners(10, borderWidth: 0, borderColor: .clear)
        dateData = generateDatesForCurrentMonthAndNext30Days()
        dateCollectionView.roundCorners(0, borderWidth: 1, borderColor: UIColor(hex: "#E8E2E2"))
        
        if let index = dateData.firstIndex(of: selectedDate!) {
            let indexPath = IndexPath(item: index, section: 0)
            dateCollectionView.selectItem(at: indexPath, animated: false, scrollPosition: .centeredHorizontally)
            collectionView(dateCollectionView, didSelectItemAt: indexPath)
        }
        
    }
    
    func generateDatesForCurrentMonthAndNext30Days() -> [Date] {
        let calendar = Calendar.current
        let currentDate = Date()
        let currentDateComponents = calendar.dateComponents([.year, .month], from: currentDate)
        
        guard let startOfMonth = calendar.date(from: currentDateComponents),
              let endOfMonth = calendar.date(byAdding: DateComponents(month: 1, day: -1), to: startOfMonth) else {
            return []
        }
        
        var dates: [Date] = []
        var currentDay = currentDate
        
        for _ in 0..<30 {
            if currentDay >= startOfMonth && currentDay <= endOfMonth {
                dates.append(currentDay)
            }
            
            currentDay = calendar.date(byAdding: .day, value: 1, to: currentDay)!
        }
        
        return dates
    }
    
    func getDayName(for date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE"
        return dateFormatter.string(from: date)
    }
    
    func getMonthName(for date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        return dateFormatter.string(from: date)
    }
    
    //MARK: - API - didFinish -
    func didFinishFetchingData(with result: Result<Void, Error>) {
        switch result {
        case .success:
            DispatchQueue.main.async {
                self.slotTimeCollectionView.reloadData()
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
        }
    }
}

//MARK: - UICollectionViewDataSource -
extension DateSelectionViewController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == dateCollectionView {
            return dateData.count
        } else {
            return slotsViewModel.slotsData.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == dateCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "DateCell", for: indexPath) as! DateCollectionViewCell
            let currentDate = dateData[indexPath.item]
            cell.dateLabel.text = "\(Calendar.current.component(.day, from: currentDate))"
            cell.dayLabel.text = getDayName(for: currentDate)
            cell.monthLabel.text = getMonthName(for: currentDate)
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SlotTimeCell", for: indexPath) as! SlotTimeCollectionViewCell
            let slotInfo = slotsViewModel.slotsData[indexPath.item].slotName
            let staus = slotsViewModel.slotsData[indexPath.item].slotActive
            if staus == false {
                cell.slotTimeLabel.textColor = UIColor.white
                cell.roundCorners(5, borderWidth: 0, borderColor: .clear)
                cell.backgroundColor = UIColor(hex: "#E3E3E3")
            } else {
                cell.slotTimeLabel.textColor = UIColor(hex: "#5B6180")
                cell.roundCorners(5, borderWidth: 1, borderColor: UIColor(hex: "#C7CFFC"))
                cell.backgroundColor = UIColor(hex: "#F0F5FF")
            }
            cell.slotTimeLabel.text = slotInfo
            return cell
        }
    }
}

//MARK: - UICollectionViewDelegateFlowLayout -
extension DateSelectionViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == dateCollectionView {
            return CGSize(width: 60, height: 60)
        } else {
            let collectionViewWidth = collectionView.bounds.width
            let cellWidth = (collectionViewWidth - 16) / 2
            return CGSize(width: cellWidth, height: 50)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.allowsSelection = true
        collectionView.allowsMultipleSelection = false
        
        if collectionView == dateCollectionView {
            selectedDate = dateData[indexPath.row]
            hitApi(withDate: selectedDate!)
            
            if let previousSelectedIndexPath = selectedDateIndexPath,
               let previousSelectedCell = collectionView.cellForItem(at: previousSelectedIndexPath) as? DateCollectionViewCell {
                previousSelectedCell.dateLabel.textColor = .black
                previousSelectedCell.dayLabel.textColor = .black
                previousSelectedCell.monthLabel.textColor = .black
                previousSelectedCell.contentView.backgroundColor = .clear
            }
            
            selectedDateIndexPath = indexPath
            selectedDate = dateData[indexPath.row]
            
            if let selectedCell = collectionView.cellForItem(at: indexPath) as? DateCollectionViewCell {
                selectedCell.dateLabel.textColor = .white
                selectedCell.dayLabel.textColor = .white
                selectedCell.monthLabel.textColor = .white
                selectedCell.contentView.backgroundColor = UIColor(hex: "#4D60D1")
            }
        } else {
            let selectedSlot = slotsViewModel.slotsData[indexPath.row]
            currentSlot = selectedSlot
            if let previousSelectedIndexPath = selectedSlotIndexPath,
               let previousSelectedCell = collectionView.cellForItem(at: previousSelectedIndexPath) as? SlotTimeCollectionViewCell {
                previousSelectedCell.slotTimeLabel.textColor = .black
                previousSelectedCell.contentView.backgroundColor = .clear
            }
            
            selectedSlotIndexPath = indexPath
            
            if selectedSlot.slotActive! {
                if let selectedCell = collectionView.cellForItem(at: indexPath) as? SlotTimeCollectionViewCell {
                    selectedCell.slotTimeLabel.textColor = .white
                    selectedCell.contentView.backgroundColor = UIColor(hex: "#4D60D1")
                }
            } else {
                AlertManager.showAlert(title: "Warning", message: "This slot is already full", viewController: self)
                collectionView.deselectItem(at: indexPath, animated: false)
            }
        }
    }
}
