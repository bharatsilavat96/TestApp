//
//  LoginViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class LoginViewController: UIViewController, LoginViewModelDelegate {
    
    //MARK: - IBOulets -
    @IBOutlet private weak var emailIdTextField: UITextField!
    @IBOutlet private weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet private weak var createAnAccountButton: UIButton!
    @IBOutlet weak var passwordView: UIView!
    @IBOutlet weak var passwordToggleButton: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    
    //MARK: - Variables -
    private var viewModel = LoginViewModel()
    var isEyeOpen = false
    
    //MARK: - ViewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        manageUI()
    }
    
    //MARK: - IBActions -
    @IBAction private func loginButtonTapped(_ sender: UIButton) {
        guard let email = emailIdTextField.text, let password = passwordTextField.text else {
            AlertManager.showAlert(title: "Alert", message: "Incorrect email or password. Please try again.", viewController: self)
            return
        }
        if ValidationManager.isValidEmail(email) {
            viewModel.loginUser(email: email, password: password)
        } else {
            AlertManager.showAlert(title: "Alert", message: "Please enter a valid email Id", viewController: self)
        }
    }
    
    
    @IBAction func passwordSecureToggleAction(_ sender: Any) {
        isEyeOpen.toggle()
        passwordTextField.isSecureTextEntry = !isEyeOpen
        let imageName = isEyeOpen ? "icons8-eyes-32" : "icons8-eyes-32 1"
        passwordToggleButton.setImage(UIImage(named: imageName), for: .normal)
    }
    
    @IBAction func newUserButtonAction(_ sender: Any) {
        print("New User Button Tapped")
        
    }
    
    //MARK: - Functions -
    private func manageUI() {
        viewModel.delegate = self
        passwordTextField.isSecureTextEntry = true
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name:UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name:UIResponder.keyboardWillHideNotification, object: nil)
        passwordView.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        self.emailIdTextField.roundCorners(10, borderWidth: 1, borderColor: UIColor(hex: "#DADADA"))
        loginButton.roundCorners(10, borderWidth: 0, borderColor: .blue)
        let underlineAttribute = [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.thick.rawValue]
        let underlineAttributedString = NSAttributedString(string: "Create an account", attributes: underlineAttribute)
        createAnAccountButton.setAttributedTitle(underlineAttributedString, for: .normal)
    }
    
    //MARK: - API didFinish -
    func didFinishLogin(with result: Result<SignInResponse, Error>) {
        switch result {
        case .success(let signInResponse):
            print("User ID: \(signInResponse.userId)")
            print("Message: \(signInResponse.message)")
            
            let myUserID: Int = signInResponse.userId
            UserDefaults.standard.set(myUserID, forKey: "myUserIdKey")
            
            DispatchQueue.main.sync {
                let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "BookingVC") as! BookingViewController
                goToVC.title = "Booking history"
                let navController = UINavigationController(rootViewController: goToVC)
                navController.modalPresentationStyle = .fullScreen
                present(navController, animated: true, completion: nil)
            }
        case .failure(let error):
            AlertManager.showAlert(title: "Alert", message: "Login failed", viewController: self)
            print("Login failed: \(error)")
        }
    }
}

//MARK: - Keyboard Manage -
extension LoginViewController{
    @objc func keyboardWillShow(notification:NSNotification) {
        
        guard let userInfo = notification.userInfo else { return }
        var keyboardFrame:CGRect = (userInfo[UIResponder.keyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height + 20
        scrollView.contentInset = contentInset
    }
    
    @objc func keyboardWillHide(notification:NSNotification) {
        
        let contentInset:UIEdgeInsets = UIEdgeInsets.zero
        scrollView.contentInset = contentInset
    }
}
