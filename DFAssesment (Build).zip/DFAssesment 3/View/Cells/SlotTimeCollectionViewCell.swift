//
//  SlotTimeCollectionViewCell.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import UIKit

class SlotTimeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var slotTimeLabel: UILabel!
    
}
