//
//  AvailabilityCollectionViewCell.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import UIKit

class AvailabilityCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var workSpaceNameLabel: UILabel!
    
}
