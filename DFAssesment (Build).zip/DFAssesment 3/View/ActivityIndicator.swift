//
//  ActivityIndicator.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 01/12/23.
//

import Foundation
import UIKit

class ActivityIndicatorController: UIViewController {
    
    @IBOutlet weak var loadingIndicator: UIActivityIndicatorView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        loadingIndicator.startAnimating()
    }
    override func viewDidDisappear(_ animated: Bool) {
        loadingIndicator.stopAnimating()
    }
}
extension UIViewController {
    func showLoading(){
        
        let storyboard: UIStoryboard = UIStoryboard(name: "Login", bundle: nil)
        let loadingVC = storyboard.instantiateViewController(withIdentifier: "ActivityIndicatorController")
        loadingVC.view.tag = 100
        loadingVC.view.frame = self.view.bounds
        
        self.view.addSubview(loadingVC.view)
    }
    
    func removeLoading() {
        
        let views = self.view.subviews.filter({ $0.tag == 100 })
        if views.count > 0{
            let view = views[0]
            view.removeFromSuperview()
        }
    }
}
