//
//  BookingViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class BookingViewController: UIViewController,UINavigationBarDelegate {
    
    //MARK: - IBOulets -
    @IBOutlet weak var coWorkingButton: UIButton!
    @IBOutlet weak var bookingHistoryButton: UIButton!
    @IBOutlet weak var bookWorkStationButton: UIButton!
    @IBOutlet weak var meetingRoomButton: UIButton!
    
    //MARK: - Variables -
    var isRoomOpen: Bool = false
    
    //MARK: - ViewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        bookWorkStationButton.isSelected = true
    }
    
    //MARK: - IBActions -
    @IBAction func goWorkingButtonAction(_ sender: Any) {
        print("Co Working Button tapped")
    }
    
    @IBAction func bookingHistoryButtonAction(_ sender: Any) {
        print("Booking History Button Tapped")
        let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "HistoryVC") as! BookingHistoryViewController
        goToVC.title = "Booking history"
        goToVC.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(goToVC, animated: true)
    }
    
    @IBAction func bookWorkStationButtonAction(_ sender: Any) {
        isRoomOpen = false
        print("Book Work Station Button Tapped")
        let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "DateSelectionVC") as! DateSelectionViewController
        goToVC.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(goToVC, animated: true)
    }
    
    @IBAction func meetingRoomButtonAction(_ sender: Any) {
        print("DateSelectionVC")
        isRoomOpen = true
        bookWorkStationButton.isSelected = false
        let goToVC = self.storyboard?.instantiateViewController(withIdentifier: "DateSelectionVC") as! DateSelectionViewController
        goToVC.isRoomOpen = isRoomOpen
        goToVC.modalPresentationStyle = .fullScreen
        navigationController?.pushViewController(goToVC, animated: true)
    }
    
    //MARK: - Functions -
    private func setupUI(){
        bookWorkStationButton.roundCorners(15, borderWidth: 0, borderColor: .blue)
        meetingRoomButton.roundCorners(15, borderWidth: 0, borderColor: .blue)
        bookingHistoryButton.roundCorners(4, borderWidth: 0, borderColor: .blue)
    }
}
