//
//  AvailableDeskViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class AvailableDeskViewController: UIViewController,AvailabilityViewModelDelegate {
    
    //MARK: - Outlets -
    @IBOutlet weak var availabilityDeskCollectionView: UICollectionView!
    @IBOutlet weak var bookDeskButton: UIButton!
    @IBOutlet weak var bookingDateAndTimeLabel: UILabel!
    
    //MARK: - Variables -
    let availabilityModel = AvailabilityViewModel()
    var currentBokingDetail : AvailabilityInfo?
    var bookedslot:SlotsInfo?
    var bookedDate:Date?
    var isRoomOpen: Bool?
    
    //MARK: - ViewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    //MARK: - IBActions -
    @IBAction func bookDeskButtonAction(sender:UIButton){
        if currentBokingDetail != nil {
            let backgroundView = UIVisualEffectView(effect: UIBlurEffect(style: .dark))
            backgroundView.frame = view.bounds
            backgroundView.alpha = 0.5
            backgroundView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            backgroundView.tag = 123
            view.addSubview(backgroundView)
            
            if let infoViewController = storyboard?.instantiateViewController(withIdentifier: "PopOverViewController") as? PopOverViewController {
                infoViewController.modalPresentationStyle = .overCurrentContext
                infoViewController.modalTransitionStyle = .crossDissolve
                
                infoViewController.backgroundView = backgroundView
                infoViewController.selectedDate = self.bookedDate
                infoViewController.selectedSlot = self.bookedslot
                infoViewController.navigationDelegate = self
                
                if let isRoomOpen = isRoomOpen {
                    infoViewController.isRoomOpen = isRoomOpen
                } else {
                    print("Meeting room is not selected")
                }
                
                present(infoViewController, animated: true)
            }
        } else {
            AlertManager.showAlert(title: "Attention!", message: "Please select slot first", viewController: self)
        }
    }
    
    //MARK: - Functions -
    private func setupUI(){
        availabilityModel.delegate = self
        if let bookedDate = bookedDate, let bookedslotId = bookedslot{
            availabilityModel.fetchData(for: bookedDate, slotId: bookedslotId.slotId!)
        }
        let formattedDateString = formatToCustomString(date: bookedDate!)
        bookingDateAndTimeLabel.text = "\(formattedDateString) , \(bookedslot?.slotName ?? "")"
        
        availabilityDeskCollectionView.delegate = self
        availabilityDeskCollectionView.dataSource = self
        bookDeskButton.roundCorners(10, borderWidth: 0, borderColor: .clear)
        bookDeskButton.backgroundColor = UIColor(hex: "#5167EB")
    }
    
    func formatToCustomString(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE d MMM"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    
    //MARK: - API - didFinsh -
    func didFinishFetchingData(with result: Result<Void, Error>) {
        switch result {
        case .success:
            DispatchQueue.main.async {
                self.availabilityDeskCollectionView.reloadData()
            }
        case .failure(let error):
            print("Error fethcing data; \(error)")
        }
    }
}

//MARK: - //MARK: - UICollectionViewDataSource -
extension AvailableDeskViewController: UICollectionViewDataSource{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return availabilityModel.availabilityData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AvailabilityCollectionViewCell", for: indexPath) as! AvailabilityCollectionViewCell
        let workSpace = availabilityModel.availabilityData[indexPath.row].workSpaceName
        let status = availabilityModel.availabilityData[indexPath.row].workSpaceActive
        if status == false {
            cell.roundCorners(5, borderWidth: 1, borderColor: .clear)
            cell.backgroundColor = UIColor(hex: "#E3E3E3")
            cell.workSpaceNameLabel.textColor = .white
        } else {
            cell.roundCorners(5, borderWidth: 1, borderColor: UIColor(hex: "#C7CFFC"))
            cell.backgroundColor = UIColor(hex: "#F0F5FF")
        }
        cell.workSpaceNameLabel.text = workSpace
        return cell
    }
}

//MARK: - //MARK: - UICollectionViewDelegateFlowLayout  -
extension AvailableDeskViewController: UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 50, height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedWorkSpace = availabilityModel.availabilityData[indexPath.row]
        currentBokingDetail = selectedWorkSpace
        collectionView.allowsSelection = true
        collectionView.allowsMultipleSelection = false
        
        if selectedWorkSpace.workSpaceActive!{
            for cell in collectionView.visibleCells {
                cell.contentView.backgroundColor = .clear
            }
            if let selectedCell = collectionView.cellForItem(at: indexPath) as? AvailabilityCollectionViewCell {
                selectedCell.workSpaceNameLabel.textColor = .white
                selectedCell.contentView.backgroundColor = UIColor(hex: "#4D60D1")
            }
        } else {
            AlertManager.showAlert(title: "Warning", message: "This desk is already Booked", viewController: self)
        }
    }
}

extension AvailableDeskViewController: NavigationHandlerDelegate {
    
    func popToRootViewController() {
        navigationController?.popToRootViewController(animated: true)
    }
    
}
