//
//  BookingHistoryViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import UIKit

class BookingHistoryViewController: UIViewController, GetBookingViewModelDelegate {
    
    //MARK: - Outlets -
    @IBOutlet weak var bookingHistoryTableView: UITableView!
    
    //MARK: - Variables -
    let getBookingsModel = GetBookingViewModel()
    
    //MARK: - viewDidLoads -
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        self.title = "Booking history"
    }
    
    //MARK: - Functions -
    private func setupUI(){
        if let retrievedInt = UserDefaults.standard.value(forKey: "myUserIdKey") as? Int {
            print("Retrieved UserId - value: \(retrievedInt)")
            getBookingsModel.fetchData(forId: retrievedInt)
        } else {
            print("No value found for the key or the value is not an Int.")
        }
        getBookingsModel.delegate = self
        bookingHistoryTableView.delegate = self
        bookingHistoryTableView.dataSource = self
        bookingHistoryTableView.separatorStyle = .none
        
    }
    
    //MARK: - API - didFinish -
    func didFinishFetchingData(with result: Result<Void, Error>) {
        switch result{
        case .success:
            DispatchQueue.main.async {
                self.bookingHistoryTableView.reloadData()
            }
        case .failure(let error):
            print("Fetching Error : \(error)")
        }
    }
}

//MARK: - UItableViewDataSource -
extension BookingHistoryViewController: UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = getBookingsModel.bookingData.count
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "BookingHistoryTableViewCell", for: indexPath) as! BookingHistoryTableViewCell
        cell.backGroundView.roundCorners(10, borderWidth: 0, borderColor: .clear)
        let data =  getBookingsModel.bookingData[indexPath.row]
        cell.bookedOnLabel.text = data.bookingDate
        cell.deskIdLabel.text = "\(data.workSpaceId ?? 0)"
        cell.nameLabel.text = data.workSpaceName
        return cell
    }
}

//MARK: - UItableViewDelegate -
extension BookingHistoryViewController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
}

