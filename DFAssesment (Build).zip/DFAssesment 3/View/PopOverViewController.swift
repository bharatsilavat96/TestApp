//
//  PopOverViewController.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import UIKit

protocol NavigationHandlerDelegate: NSObject {
    func popToRootViewController()
}

class PopOverViewController: UIViewController {
    
    //MARK: - Outlets -
    @IBOutlet weak var cancelAlertButton: UIButton!
    @IBOutlet weak var alertDeskIdLabel: UILabel!
    @IBOutlet weak var alertDeskNoLabel: UILabel!
    @IBOutlet weak var alertSlotTimeLabel: UILabel!
    @IBOutlet weak var alertConfirmButton: UIButton!
    
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var roomIdlabel: UILabel!
    @IBOutlet weak var roomNoLabel: UILabel!
    @IBOutlet weak var roomBookingDateLabel: UILabel!
    @IBOutlet weak var roomBookingView: UIView!
    @IBOutlet weak var roomBookingConfirmButton: UIButton!
    
    //MARK: - Variables -
    var selectedDate: Date?
    var selectedSlot: SlotsInfo?
    var backgroundView: UIView?
    var isRoomOpen: Bool?
    weak var navigationDelegate: NavigationHandlerDelegate?
    
    //MARK: - viewDidLoad -
    override func viewDidLoad() {
        super.viewDidLoad()
        roomBookingView.isHidden = true
        alertView.isHidden = true
        if let isRoomOpen = isRoomOpen {
            if isRoomOpen{
                showRoomBookingView()
            } else {
                showAlertView()
            }
        } else {
            print("Not getting Values")
        }
        
        if let selectedSlot = selectedSlot, let selectedDate = selectedDate {
            alertDeskNoLabel.text = "1234"
            alertDeskIdLabel.text = "\(selectedSlot.slotId ?? 0)"
            let date = formatToCustomString(date: selectedDate)
            alertSlotTimeLabel.text = "\(date) , \(selectedSlot.slotName ?? "")"
        }
        backgroundView?.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        roomBookingConfirmButton.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        alertView.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        alertConfirmButton.roundCorners(5, borderWidth: 0, borderColor: .clear)
    }
    
    //MARK: - IBActions -
    @IBAction func confirmBookingAction(sender: UIButton) {
        if sender.tag == 1 {
            _ = ToastView(successMessage: "Success", message: "You have successfully booked your Desk.", icon: UIImage(named: "ep_success-filled"))
            dismissPopOverViewController(moveToRoot: true)
            
        } else {
            print("sender 2 is for Room Booking")
        }
    }
    
    @IBAction func cancelButtonAction(sender:UIButton){
        print("Cancel button Tapped")
        dismissPopOverViewController()
    }
    
    
    @IBAction func roomConfirmButtonAction(_ sender: Any) {
        print("Confirm room button tapped")
        let tost = ToastView(successMessage: "Success", message: "You have successfully booked your Desk.", icon: UIImage(named: "ep_success-filled"))
         dismissPopOverViewController(moveToRoot: true)
    }
    
    //MARK: - Functions -
    func dismissPopOverViewController(moveToRoot: Bool = false) {
        dismiss(animated: true) { [weak self] in
            if let backgroundView = self?.backgroundView {
                backgroundView.removeFromSuperview()
            }
            guard moveToRoot else { return }
            self?.navigationDelegate?.popToRootViewController()
        }
    }
    
    
    func formatToCustomString(date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE d MMM"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    func showRoomBookingView() {
        alertView.isHidden = true
        roomBookingView.isHidden = false
        
        roomBookingView.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        roomBookingConfirmButton.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        
        if let selectedSlot = selectedSlot, let selectedDate = selectedDate {
            roomNoLabel.text = "123" // Set room number or data based on your logic
            roomIdlabel.text = "\(selectedSlot.slotId ?? 0)" // Set room ID or data based on your logic
            roomBookingDateLabel.text = formatToCustomString(date: selectedDate)
        }
    }
    
    func showAlertView() {
        roomBookingView.isHidden = true
        alertView.isHidden = false
        
        alertView.roundCorners(10, borderWidth: 0.5, borderColor: .clear)
        alertConfirmButton.roundCorners(5, borderWidth: 0, borderColor: .clear)
    }
    
}
