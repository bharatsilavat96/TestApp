//
//  SlotsModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct Slots: Codable{
    var slots: [SlotsInfo]?
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(self.slots, forKey: .slots)
    }
    enum CodingKeys: CodingKey {
        case slots
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.slots = try container.decode([SlotsInfo].self, forKey: .slots)
    }
}

struct SlotsInfo: Codable {
    let slotName: String?
    let slotId: Int?
    let slotActive: Bool?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.slotName, forKey: .slotName)
        try container.encodeIfPresent(self.slotId, forKey: .slotId)
        try container.encodeIfPresent(self.slotActive, forKey: .slotActive)
    }
    
    enum CodingKeys: String, CodingKey {
        case slotName = "slot_name"
        case slotId = "slot_id"
        case slotActive = "slot_active"
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.slotName = try container.decodeIfPresent(String.self, forKey: .slotName)
        self.slotId = try container.decodeIfPresent(Int.self, forKey: .slotId)
        self.slotActive = try container.decodeIfPresent(Bool.self, forKey: .slotActive)
    }
}

