//
//  CreateAccountModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct SignUpResponse: Codable {
    let userId: Int
    let message: String

    enum CodingKeys: String, CodingKey {
        case userId = "user_id"
        case message
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(self.userId, forKey: .userId)
        try container.encode(self.message, forKey: .message)
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.userId = try container.decode(Int.self, forKey: .userId)
        self.message = try container.decode(String.self, forKey: .message)
    }
}
