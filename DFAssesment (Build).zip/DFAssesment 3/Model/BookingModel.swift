//
//  BookingModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

struct BookingModel: Codable {
    
    let bookings: [Bookings]?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.bookings, forKey: .bookings)
    }
    enum CodingKeys: CodingKey {
        case bookings
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.bookings = try container.decodeIfPresent([Bookings].self, forKey: .bookings)
    }
}

struct Bookings: Codable {
    let workSpaceName: String?
    let workSpaceId: Int?
    let bookingDate: String?
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encodeIfPresent(self.workSpaceName, forKey: .workSpaceName)
        try container.encodeIfPresent(self.workSpaceId, forKey: .workSpaceId)
        try container.encodeIfPresent(self.bookingDate, forKey: .bookingDate)
    }
    enum CodingKeys: String,CodingKey {
        case workSpaceName = "workspace_name"
        case workSpaceId = "workspace_id"
        case bookingDate = "booking_date"
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        self.workSpaceName = try container.decodeIfPresent(String.self, forKey: .workSpaceName)
        self.workSpaceId = try container.decodeIfPresent(Int.self, forKey: .workSpaceId)
        self.bookingDate = try container.decodeIfPresent(String.self, forKey: .bookingDate)
    }
    
    
}
