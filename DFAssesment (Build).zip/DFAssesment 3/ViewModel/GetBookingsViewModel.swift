//
//  GetBookingsViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import Foundation
import UIKit

class GetBookingViewModel {
    private let connectionManager: ConnectionManager
    var bookingData: [Bookings] = []
    
    weak var delegate: GetBookingViewModelDelegate?
    
    init(connectionManager: ConnectionManager = ConnectionManager()) {
        self.connectionManager = connectionManager
        self.connectionManager.delegate = self
    }
    
    func fetchData(forId: Int) {
        connectionManager.startSession(endpoint: .getBookings, method: .get, parameters: ["user_id": forId])
    }
}

extension GetBookingViewModel: ConnectionManagerDelegate {
    func didCompleteTask(with result: Result<Data, Error>) {
        switch result {
        case .success(let data):
            do {
                let decoder = JSONDecoder()
                let bookingInfo = try decoder.decode(BookingModel.self, from: data)
                bookingData = bookingInfo.bookings ?? []
                delegate?.didFinishFetchingData(with: .success(()))
            } catch {
                print("Error decoding JSON: \(error)")
                delegate?.didFinishFetchingData(with: .failure(error))
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
            delegate?.didFinishFetchingData(with: .failure(error))
        }
    }
}

protocol GetBookingViewModelDelegate: AnyObject {
    func didFinishFetchingData(with result: Result<Void, Error>)
}
