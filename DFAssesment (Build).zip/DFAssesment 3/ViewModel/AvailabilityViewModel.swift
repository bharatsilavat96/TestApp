//
//  AvailabilityViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import Foundation
import UIKit

class AvailabilityViewModel {
    private let connectionManager: ConnectionManager
    var availabilityData: [AvailabilityInfo] = []
    
    weak var delegate: AvailabilityViewModelDelegate?
    
    init(connectionManager: ConnectionManager = ConnectionManager()) {
        self.connectionManager = connectionManager
        self.connectionManager.delegate = self
    }
    
    func fetchData(for date: Date, slotId: Int) {
        let formattedDate = DateFormatter.localizedString(from: date, dateStyle: .short, timeStyle: .none)
        
        connectionManager.startSession(endpoint: .getAvailability, method: .get, parameters: ["date": formattedDate, "slot_id": slotId])
    }
}

extension AvailabilityViewModel: ConnectionManagerDelegate {
    func didCompleteTask(with result: Result<Data, Error>) {
        switch result {
        case .success(let data):
            do {
                let decoder = JSONDecoder()
                let availabilityInfo = try decoder.decode(AvilabilityModel.self, from: data)
                availabilityData = availabilityInfo.availability ?? []
                delegate?.didFinishFetchingData(with: .success(()))
            } catch {
                print("Error decoding JSON: \(error)")
                delegate?.didFinishFetchingData(with: .failure(error))
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
            delegate?.didFinishFetchingData(with: .failure(error))
        }
    }
}

protocol AvailabilityViewModelDelegate: AnyObject {
    func didFinishFetchingData(with result: Result<Void, Error>)
}
