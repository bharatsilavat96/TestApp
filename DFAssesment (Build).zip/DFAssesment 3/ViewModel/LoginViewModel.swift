//
//  LoginViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

class LoginViewModel {
    private let connectionManager: ConnectionManager
    
    weak var delegate: LoginViewModelDelegate?
    
    init(connectionManager: ConnectionManager = ConnectionManager()) {
        self.connectionManager = connectionManager
        self.connectionManager.delegate = self
    }
    
    func loginUser(email: String, password: String) {
        let loginEndpoint = APIEndpoint.login
        
        let parameters: [String: Any] = ["email": email, "password": password]
        
        
        connectionManager.startSession(endpoint: loginEndpoint, method: .post, parameters: parameters)
    }
}

extension LoginViewModel: ConnectionManagerDelegate {
    func didCompleteTask(with result: Result<Data, Error>) {
        switch result {
        case .success(let data):
            do {
                let decoder = JSONDecoder()
                let signInResponse = try decoder.decode(SignInResponse.self, from: data)
                delegate?.didFinishLogin(with: .success(signInResponse))
            } catch {
                print("Error decoding JSON: \(error)")
                delegate?.didFinishLogin(with: .failure(error))
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
            delegate?.didFinishLogin(with: .failure(error))
        }
    }
}

protocol LoginViewModelDelegate: AnyObject {
    func didFinishLogin(with result: Result<SignInResponse, Error>)
}
