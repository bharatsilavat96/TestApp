//
//  SlotViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 30/11/23.
//

import Foundation

class SlotsViewModel {
    private let connectionManager: ConnectionManager
    var slotsData: [SlotsInfo] = []
    
    weak var delegate: SlotsViewModelDelegate?
    
    init(connectionManager: ConnectionManager = ConnectionManager()) {
        self.connectionManager = connectionManager
        self.connectionManager.delegate = self
    }
    
    func fetchData(for date: Date) {
        let formattedDate = DateFormatter.localizedString(from: date, dateStyle: .short, timeStyle: .none)
        
        connectionManager.startSession(endpoint: .getSlots, method: .get, parameters: ["date": formattedDate])
    }
}

extension SlotsViewModel: ConnectionManagerDelegate {
    func didCompleteTask(with result: Result<Data, Error>) {
        switch result {
        case .success(let data):
            do {
                let decoder = JSONDecoder()
                let slots = try decoder.decode(Slots.self, from: data)
                slotsData = slots.slots ?? []
                delegate?.didFinishFetchingData(with: .success(()))
            } catch {
                print("Error decoding JSON: \(error)")
                delegate?.didFinishFetchingData(with: .failure(error))
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
            delegate?.didFinishFetchingData(with: .failure(error))
        }
    }
}

protocol SlotsViewModelDelegate: AnyObject {
    func didFinishFetchingData(with result: Result<Void, Error>)
}
