//
//  CreateAccountViewModel.swift
//  DFAssesment
//
//  Created by Bharat Shilavat on 29/11/23.
//

import Foundation

class SignUpViewModel {
    private let connectionManager: ConnectionManager
    
    weak var delegate: SignUpViewModelDelegate?
    
    init(connectionManager: ConnectionManager = ConnectionManager()) {
        self.connectionManager = connectionManager
        self.connectionManager.delegate = self
    }
    
    func signUpUser(email: String, password: String) {
        let signUpEndpoint = APIEndpoint.createAccount
        
        let parameters: [String: Any] = ["email": email, "password": password]
        
        connectionManager.startSession(endpoint: signUpEndpoint, method: .post, parameters: parameters)
    }
}

extension SignUpViewModel: ConnectionManagerDelegate {
    func didCompleteTask(with result: Result<Data, Error>) {
        switch result {
        case .success(let data):
            do {
                let decoder = JSONDecoder()
                let signUpResponse = try decoder.decode(SignUpResponse.self, from: data)
                delegate?.didFinishSignUp(with: .success(signUpResponse))
            } catch {
                print("Error decoding JSON: \(error)")
                delegate?.didFinishSignUp(with: .failure(error))
            }
        case .failure(let error):
            print("Error fetching data: \(error)")
            delegate?.didFinishSignUp(with: .failure(error))
        }
    }
}

protocol SignUpViewModelDelegate: AnyObject {
    func didFinishSignUp(with result: Result<SignUpResponse, Error>)
}
